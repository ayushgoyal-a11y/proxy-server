#!/usr/bin/env node

import express from 'express';
import axios from 'axios';

const PORT = process.env.EXTENSION_PORT || 4001;
const LAMBDA_EXTENSIONS_API = process.env.AWS_LAMBDA_RUNTIME_API || 'http://localhost:9001';
const EXTENSION_NAME = 'lambda-extension';

// State tracking
let extensionId = null;
let isRunning = true;

const app = express();

// Middleware
app.use(express.json());

// Health endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    extensionId,
    version: '1.0.0',
    timestamp: new Date().toISOString(),
  });
});

// Ready endpoint
app.get('/ready', (req, res) => {
  res.json({
    status: isRunning ? 'ready' : 'not-ready',
    timestamp: new Date().toISOString(),
  });
});

// Metrics endpoint
app.get('/metrics', (req, res) => {
  res.json({
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    timestamp: new Date().toISOString(),
  });
});

// Basic ping
app.get('/ping', (req, res) => {
  res.json({ pong: true });
});

// Error handling
app.use((err, req, res, next) => {
  console.error('Express error:', err);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message,
  });
});

// Register with Lambda Extensions API
async function registerExtension() {
  try {
    const params = {
      events: ['INVOKE', 'SHUTDOWN'],
    };

    const response = await axios.post(
      `${LAMBDA_EXTENSIONS_API}/2020-01-01/extension/register`,
      JSON.stringify(params),
      {
        headers: {
          'Content-Type': 'application/json',
          'Lambda-Extension-Name': EXTENSION_NAME,
        },
        timeout: 1000,
      }
    );

    extensionId = response.headers['lambda-extension-identifier'];
    console.log(`Extension registered with ID: ${extensionId}`);
    return extensionId;
  } catch (error) {
    if (error.code === 'ECONNREFUSED' || error.code === 'ENOTFOUND') {
      console.log('Lambda Runtime API not available - running in standalone mode');
      console.log('Note: Extension will not process Lambda lifecycle events');
      return null;
    }
    console.error('Failed to register extension:', error.message);
    return null;
  }
}

// Process Lambda events
async function processEvents() {
  if (!extensionId) {
    console.log('Waiting for extension registration...');
    return;
  }

  try {
    const response = await axios.get(
      `${LAMBDA_EXTENSIONS_API}/2020-01-01/extension/event/next`,
      {
        headers: {
          'Lambda-Extension-Identifier': extensionId,
        },
        timeout: 0, // No timeout for blocking call
      }
    );

    const event = response.data;
    console.log(`Event received: ${event.eventType}`, JSON.stringify(event, null, 2));

    switch (event.eventType) {
      case 'INVOKE':
        console.log(`Processing INVOKE event for request: ${event.requestId}`);
        break;
      case 'SHUTDOWN':
        console.log(`SHUTDOWN event received: ${event.shutdownReason}`);
        isRunning = false;
        process.exit(0);
        break;
      default:
        console.log(`Unknown event type: ${event.eventType}`);
    }

    // Immediately poll for next event
    setImmediate(processEvents);
  } catch (error) {
    if (error.code === 'ECONNREFUSED') {
      console.log('Lambda Runtime API not available, running in standalone mode');
      // Allow extension to keep running in standalone mode
      setTimeout(processEvents, 5000);
    } else {
      console.error('Error processing events:', error.message);
      setTimeout(processEvents, 5000);
    }
  }
}

// Start the Express server
const server = app.listen(PORT, () => {
  console.log(`Lambda Extension server listening on port ${PORT}`);
  console.log(`Health endpoint: http://localhost:${PORT}/health`);
});

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  isRunning = false;
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  isRunning = false;
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

// Initialize extension
async function initialize() {
  try {
    // Register with Lambda Extensions API
    const id = await registerExtension();
    
    if (id) {
      console.log('Starting event processor...');
      // Start processing events in the background
      setImmediate(processEvents);
    } else {
      console.log('Skipping event processor - running in standalone mode only');
    }
  } catch (error) {
    console.error('Initialization error:', error);
    // Don't exit - allow server to continue running
  }
}

// Start the application
initialize().catch(error => {
  console.error('Fatal error during initialization:', error);
  // Don't exit - allow server to continue running in standalone mode
});
